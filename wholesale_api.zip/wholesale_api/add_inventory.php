<?php
include "db.php";

$item_name = $_POST['item_name'] ?? '';
$quantity = $_POST['quantity'] ?? 0;
$unit = $_POST['unit'] ?? '';
$price = $_POST['price'] ?? 0;

$stmt = $conn->prepare("INSERT INTO inventory (item_name, quantity, unit, price) VALUES (?, ?, ?, ?)");
$stmt->bind_param("sdsd", $item_name, $quantity, $unit, $price);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
