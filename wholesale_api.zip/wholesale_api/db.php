<?php
// Shared database connection for the wholesale_api.
// Update these values to match your XAMPP MySQL setup.

$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "wholesale_db";

$conn = new mysqli($host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
