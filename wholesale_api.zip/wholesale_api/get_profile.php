<?php
header("Content-Type: application/json");
include "db.php";

$result = $conn->query("SELECT * FROM profile WHERE id = 1 LIMIT 1");
$profile = $result->fetch_assoc();
echo json_encode($profile);
$conn->close();
