<?php
include "db.php";

$name = $_POST['name'] ?? '';
$company = $_POST['company'] ?? '';
$phone = $_POST['phone'] ?? '';

$stmt = $conn->prepare("INSERT INTO suppliers (name, company, phone) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $company, $phone);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
