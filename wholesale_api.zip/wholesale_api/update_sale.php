<?php
include "db.php";

$id = $_POST['id'] ?? '';
$client_id = $_POST['client_id'] ?? null;
$product_name = $_POST['product_name'] ?? '';
$quantity = $_POST['quantity'] ?? 0;
$unit_price = $_POST['unit_price'] ?? 0;
$total = $_POST['total'] ?? 0;
$sale_date = $_POST['sale_date'] ?? null;

if ($client_id === '') {
    $client_id = null;
}

$stmt = $conn->prepare(
    "UPDATE sales SET client_id = ?, product_name = ?, quantity = ?, unit_price = ?, total = ?, sale_date = ?
     WHERE id = ?"
);
$stmt->bind_param("isdddsi", $client_id, $product_name, $quantity, $unit_price, $total, $sale_date, $id);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
