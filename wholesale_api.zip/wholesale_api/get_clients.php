<?php
header("Content-Type: application/json");
include "db.php";

$result = $conn->query("SELECT * FROM clients ORDER BY id DESC");
$clients = [];
while ($row = $result->fetch_assoc()) {
    $clients[] = $row;
}
echo json_encode($clients);
$conn->close();
