<?php
include "db.php";

$supplier_id = $_POST['supplier_id'] ?? null;
$item_name = $_POST['item_name'] ?? '';
$quantity = $_POST['quantity'] ?? 0;
$unit_cost = $_POST['unit_cost'] ?? 0;
$total_cost = $_POST['total_cost'] ?? 0;
$purchase_date = $_POST['purchase_date'] ?? null;

if ($supplier_id === '') {
    $supplier_id = null;
}

$stmt = $conn->prepare(
    "INSERT INTO purchases (supplier_id, item_name, quantity, unit_cost, total_cost, purchase_date)
     VALUES (?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param("isddds", $supplier_id, $item_name, $quantity, $unit_cost, $total_cost, $purchase_date);

if ($stmt->execute()) {
    // Also add the purchased quantity into inventory, matching by item name.
    $check = $conn->prepare("SELECT id, quantity FROM inventory WHERE item_name = ? LIMIT 1");
    $check->bind_param("s", $item_name);
    $check->execute();
    $res = $check->get_result();

    if ($row = $res->fetch_assoc()) {
        $newQty = $row['quantity'] + $quantity;
        $upd = $conn->prepare("UPDATE inventory SET quantity = ? WHERE id = ?");
        $upd->bind_param("di", $newQty, $row['id']);
        $upd->execute();
        $upd->close();
    } else {
        $ins = $conn->prepare(
            "INSERT INTO inventory (item_name, quantity, unit, price) VALUES (?, ?, '', ?)"
        );
        $ins->bind_param("sdd", $item_name, $quantity, $unit_cost);
        $ins->execute();
        $ins->close();
    }
    $check->close();

    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
