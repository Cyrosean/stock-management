<?php
include "db.php";

$id = $_POST['id'] ?? '';
$name = $_POST['name'] ?? '';
$phone = $_POST['phone'] ?? '';

$stmt = $conn->prepare("UPDATE clients SET name = ?, phone = ? WHERE id = ?");
$stmt->bind_param("ssi", $name, $phone, $id);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
