<?php
include "db.php";

$id = $_POST['id'] ?? '';
$item_name = $_POST['item_name'] ?? '';
$quantity = $_POST['quantity'] ?? 0;
$unit = $_POST['unit'] ?? '';
$price = $_POST['price'] ?? 0;

$stmt = $conn->prepare("UPDATE inventory SET item_name = ?, quantity = ?, unit = ?, price = ? WHERE id = ?");
$stmt->bind_param("sdsdi", $item_name, $quantity, $unit, $price, $id);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
