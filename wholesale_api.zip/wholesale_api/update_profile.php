<?php
include "db.php";

$business_name = $_POST['business_name'] ?? '';
$owner_name = $_POST['owner_name'] ?? '';
$phone = $_POST['phone'] ?? '';
$email = $_POST['email'] ?? '';
$location = $_POST['location'] ?? '';

$stmt = $conn->prepare(
    "UPDATE profile SET business_name = ?, owner_name = ?, phone = ?, email = ?, location = ? WHERE id = 1"
);
$stmt->bind_param("sssss", $business_name, $owner_name, $phone, $email, $location);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
