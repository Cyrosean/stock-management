<?php
header("Content-Type: application/json");
include "db.php";

$result = $conn->query("SELECT * FROM suppliers ORDER BY id DESC");
$suppliers = [];
while ($row = $result->fetch_assoc()) {
    $suppliers[] = $row;
}
echo json_encode($suppliers);
$conn->close();
