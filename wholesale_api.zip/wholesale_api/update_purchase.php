<?php
include "db.php";

$id = $_POST['id'] ?? '';
$supplier_id = $_POST['supplier_id'] ?? null;
$item_name = $_POST['item_name'] ?? '';
$quantity = $_POST['quantity'] ?? 0;
$unit_cost = $_POST['unit_cost'] ?? 0;
$total_cost = $_POST['total_cost'] ?? 0;
$purchase_date = $_POST['purchase_date'] ?? null;

if ($supplier_id === '') {
    $supplier_id = null;
}

$stmt = $conn->prepare(
    "UPDATE purchases SET supplier_id = ?, item_name = ?, quantity = ?, unit_cost = ?, total_cost = ?, purchase_date = ?
     WHERE id = ?"
);
$stmt->bind_param("isdddsi", $supplier_id, $item_name, $quantity, $unit_cost, $total_cost, $purchase_date, $id);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
