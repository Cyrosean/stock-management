<?php
include "db.php";

$client_id = $_POST['client_id'] ?? null;
$product_name = $_POST['product_name'] ?? '';
$quantity = $_POST['quantity'] ?? 0;
$unit_price = $_POST['unit_price'] ?? 0;
$total = $_POST['total'] ?? 0;
$sale_date = $_POST['sale_date'] ?? null;

if ($client_id === '') {
    $client_id = null;
}

$stmt = $conn->prepare(
    "INSERT INTO sales (client_id, product_name, quantity, unit_price, total, sale_date)
     VALUES (?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param("isddds", $client_id, $product_name, $quantity, $unit_price, $total, $sale_date);

if ($stmt->execute()) {
    // Reduce inventory quantity for the sold item, matching by item name.
    $check = $conn->prepare("SELECT id, quantity FROM inventory WHERE item_name = ? LIMIT 1");
    $check->bind_param("s", $product_name);
    $check->execute();
    $res = $check->get_result();

    if ($row = $res->fetch_assoc()) {
        $newQty = $row['quantity'] - $quantity;
        if ($newQty < 0) {
            $newQty = 0;
        }
        $upd = $conn->prepare("UPDATE inventory SET quantity = ? WHERE id = ?");
        $upd->bind_param("di", $newQty, $row['id']);
        $upd->execute();
        $upd->close();
    }
    $check->close();

    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
