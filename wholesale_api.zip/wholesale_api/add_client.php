<?php
include "db.php";

$name = $_POST['name'] ?? '';
$phone = $_POST['phone'] ?? '';

$stmt = $conn->prepare("INSERT INTO clients (name, phone) VALUES (?, ?)");
$stmt->bind_param("ss", $name, $phone);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
