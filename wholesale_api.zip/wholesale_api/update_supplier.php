<?php
include "db.php";

$id = $_POST['id'] ?? '';
$name = $_POST['name'] ?? '';
$company = $_POST['company'] ?? '';
$phone = $_POST['phone'] ?? '';

$stmt = $conn->prepare("UPDATE suppliers SET name = ?, company = ?, phone = ? WHERE id = ?");
$stmt->bind_param("sssi", $name, $company, $phone, $id);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error: " . $stmt->error;
}
$stmt->close();
$conn->close();
