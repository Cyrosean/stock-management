<?php
header("Content-Type: application/json");
include "db.php";

$result = $conn->query("SELECT * FROM sales ORDER BY id DESC");
$sales = [];
while ($row = $result->fetch_assoc()) {
    $sales[] = $row;
}
echo json_encode($sales);
$conn->close();
