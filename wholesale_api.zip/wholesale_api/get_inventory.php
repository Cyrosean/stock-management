<?php
header("Content-Type: application/json");
include "db.php";

$result = $conn->query("SELECT * FROM inventory ORDER BY id DESC");
$inventory = [];
while ($row = $result->fetch_assoc()) {
    $inventory[] = $row;
}
echo json_encode($inventory);
$conn->close();
