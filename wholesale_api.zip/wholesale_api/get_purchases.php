<?php
header("Content-Type: application/json");
include "db.php";

$result = $conn->query("SELECT * FROM purchases ORDER BY id DESC");
$purchases = [];
while ($row = $result->fetch_assoc()) {
    $purchases[] = $row;
}
echo json_encode($purchases);
$conn->close();
